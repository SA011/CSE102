#include<stdio.h>
#include<stdlib.h>

long long int encrypt(char *p)
{
    long long int ans=0;
    char *s=p+7;
    for(; s>=p; s--)
    {
        ans*=256;
        ans+=(long long int)*s;
    }
    return ans;
}
int main()
{
    int n;
    scanf("%d",&n);

    char *str=(char*)malloc((n+1)*sizeof(char));
    if(str==NULL)return 0;

    char *p=str;

    scanf("%c",p);

    for(; p<str+n; p++)
        scanf("%c",p);

    *p='\0';

    for(p=str; p<str+n; p+=8)
    {
        printf("%lld ",encrypt(p));
    }

    free(str);

    return 0;
}
