#include<stdio.h>
#include<stdlib.h>

int* mode(int *p,int n)
{
    int *freq=(int*)malloc(10001*sizeof(int));

    int *s;

    int sz=0,cnt=1;

    for(s=freq; s<freq+10001; s++)
    {
        *s=0;
    }


    for(s=p; s<p+n; s++)
    {
        (*(freq+*s))++;
    }


    for(s=freq; s<freq+10001; s++)
    {
        if(*s>cnt)
        {
            sz=1;
            cnt=*s;
        }
        else if(*s==cnt)
        {
            sz++;
        }
    }


    int *ans=(int*)malloc((sz+1)*sizeof(int));

    *ans=sz;

    p=ans+1;

    for(s=freq; s<freq+10001; s++)
    {
        if(*s==cnt)
        {
            *p=(s-freq);
            p++;
        }
    }

    free(freq);

    return ans;
}
int main()
{
    int n,*p,*q;

    scanf("%d",&n);

    p=(int *)malloc(n*sizeof(int));
    if(p==NULL)return 0;

    for(q=p; q<p+n; q++)
        scanf("%d",q);

    int *ans=mode(p,n);

    for(q=ans+1; q<ans+1+*ans; q++)
        printf("%d ",*q);

    free(ans);
    free(p);

    return 0;
}
