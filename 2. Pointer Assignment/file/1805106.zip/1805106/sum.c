#include<stdio.h>
#include<stdlib.h>

int findsum(int *p,int n)
{
    int *s=p;
    int sum=0;
    for(; s<p+n; s+=2)
        sum+=*s;
    return sum;
}
int main()
{
    int n,*p;
    scanf("%d",&n);
    p=(int*)malloc(n*sizeof(int));
    if(p==NULL)return 0;
    int *s=p;
    for(; s<p+n; s++)
        scanf("%d",s);

    int sum1,sum2;

    sum1=findsum(p,n);

    sum2=findsum(p+1,n-1);

    if(sum1>sum2)
    {
        printf("Even index sum is greater\n");
    }
    else if(sum1<sum2)
    {
        printf("Odd index sum is greater\n");
    }
    else
    {
        printf("Equal\n");
    }
    free(p);
    return 0;
}
