/*
Features of My Solar System:
- 9 planets, 1 sun, 1 shooting star
- Twinkling stars in background   //The quality of pictures is reduced to minimize the size
- explosion occurs when shooting star hits a planet or a satellite
- press 'O' or 'o' to remove/draw the orbit of planet
- press 'S' or 's' to remove/draw the orbit of satellite
- press '+' to zoom in , '-' to zoom out and '*' to reset
- press the arrows to move the scenario
- Scenario can be moved by dragging mouse also
- press 'p' or 'P' to pause and 'r' or 'R' to resume
- press 'L' to draw/remove line from Sun to planet and 'l' to draw/remove line from planet to satellite
- press 'C' to reverse the direction of rotation of planet and 'c' for satellite
- press 'I' to increase and 'D' to decrease the speed of planet and 'i' ,'d' for satellite
- press '0'-'8' to remove/draw the planets and '9' to remove the shooting star
- press 't' or 'T' to make the background stuck/animate
*/


# include "iGraphics.h"

double pi;
int planetnum=9;

//ellipse ratio
const int gal_a=11,gal_b=9;



//key change variables

double speedoffset=0.8,speedoffset1=1;
double offset=0.55;                       //size multiplier
double move_offset=4;                    //move add
int orbitvis=1,satorbit=1;               //visibility of orbit
int rev=1,rev1=1;                        //direction of rotation
int linevis=0,linevis1=0;                //line visibility
int pause=0;                             //pause resume text display
double pic=0;                            //bg change
int exp_tim=0;                           //explosion time
double rd=5,sd=2;                        //explosion radius
int bg_stuck=0;                          //background stuck


// mouse position
double msx=-1,msy=-1;


//explosion point
double exppos[2];

//shooting star position
double starpos[2]={1200,1024};
char star[]="shootingstar2.bmp";
int str=10;
int strappear=0;

//x,y,r of sun
double sun[3]= {400,512,50};

//a,r,theta for planet
double planet[9][3]= {{230,9,0},{320,12,25},{410,15,180},{520,14,270},{630,30,30},{740,25,90},{860,17,320},{970,16,160},{1080,13,130}};

//color of planet
int planetcolor[9]= {0xb8b8b8,0xc75a00,0x5292cc,0xc1440e,0xf0d38c,0xeafffc,0x43b0d0,0x43c0c0,0xeeeeee};

//satellite [0][planet number][0] number of satellite , [0][i][1..4] radius ,[1][i] theta.....[2] for visibility
double sat[3][9][5]= {{{0},{0},{1,5},{2,6,7},{2,5,8},{3,7,6,5},{3,9,7,9},{2,7,6},{1,6}},{{},{},{0},{120,250},{310,15},{0,220,130},{60,180,310},{40,190},{170}}};

//backgrounds
char p[4][100]= {"bg4.bmp","bg4(1).bmp","bg4(2).bmp","bg4(3).bmp"};

//planet visibility
int vis[10]= {1,1,1,1,1,1,1,1,1,1};


void textoutput()
{
    iSetColor(255,255,255);
    int dis=20;
    if(!pause)
    {
        iText(10,dis,"Press 'P' to pause OR Press 'Q'/'end' to quit.");
    }
    else
    {
        iText(10,dis,"Press 'R' to resume OR press 'Q'/'end' to quit");
        iText(10,dis*2,"PAUSED!!");
    }
}
//parameters explosion point
void draw_explosion(double x, double y)
{
    double arr[2][20];
    int i=0;
    iSetColor(255,0,0);
    arr[0][i]=x-sd*offset;
    arr[1][i++]=y-sd*offset;
    arr[0][i]=x-sd*offset;
    arr[1][i++]=y-rd*offset;
    arr[0][i]=x;
    arr[1][i++]=y-sd*offset;
    arr[0][i]=x+rd*offset;
    arr[1][i++]=y-rd*offset;
    arr[0][i]=x+sd*offset;
    arr[1][i++]=y-sd*offset;
    arr[0][i]=x+rd*offset;
    arr[1][i++]=y;
    arr[0][i]=x+sd*offset;
    arr[1][i++]=y;
    arr[0][i]=x+rd*offset;
    arr[1][i++]=y+rd*offset;
    arr[0][i]=x+sd*offset;
    arr[1][i++]=y+sd*offset;
    arr[0][i]=x;
    arr[1][i++]=y+rd*offset;
    arr[0][i]=x;
    arr[1][i++]=y+sd*offset;
    arr[0][i]=x-rd*offset;
    arr[1][i++]=y+rd*offset;
    arr[0][i]=x-sd*offset;
    arr[1][i++]=y+sd*offset;
    arr[0][i]=x-rd*offset;
    arr[1][i++]=y;
    iFilledPolygon(arr[0],arr[1],i);
    iSetColor(255,125,0);
    for(int j=0;j<i;j++)
    {
        arr[0][j]=(arr[0][j]-x)*0.8+x;
        arr[1][j]=(arr[1][j]-y)*0.8+y;
    }
    iFilledPolygon(arr[0],arr[1],i);
    iSetColor(255,255,0);
    for(int j=0;j<i;j++)
    {
        arr[0][j]=(arr[0][j]-x)*0.8+x;
        arr[1][j]=(arr[1][j]-y)*0.8+y;
    }
    iFilledPolygon(arr[0],arr[1],i);
    exppos[0]=x,exppos[1]=y;
    exp_tim++;
}

//parameters.. center of ellipse x,y.. axis lengths a,b
void draworbit(double x,double y,double a,double b)
{
    iSetColor(255,255,255);
    iEllipse(x,y,a,b);
}

//parameters..  center of ellipse x,y.. axis lengths a,b..radius r...angle theta..
void drawplanet(double x,double y,double a,double b,double r,double theta)
{
    double cx=x+a*cos(theta*pi/180);
    double cy=y+b*sin(theta*pi/180);
    iFilledCircle(cx,cy,r);
}

// returns distance of 2 points (x,y) and (x1,y1)
double distance(double x,double y,double x1,double y1)
{
    return sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1));
}

//parameters coordinate of sun..axis length 'a' of planet and theta of planet....a,r,theta of satellite...ind1 planet index no and ind2 satellite index number
void drawsat(double sun_x,double sun_y,double planet_a,double planet_th,double a,double r,double theta,int ind1,int ind2)
{
    double b1=planet_a*gal_b/gal_a;                                             // b of planet orbit
    double e1=sqrt(1.0-(b1*b1)/(planet_a*planet_a));                           //eccentricity for planet orbit
    sun_x=sun_x+planet_a*e1;                                                   //center of orbit
    double px=sun_x+planet_a*cos(planet_th*pi/180);                            //planet center
    double py=sun_y+b1*sin(planet_th*pi/180);
    double b=a*gal_b/gal_a;                                                    //b of satellite orbit
    double e=sqrt(1.0-(b*b)/(a*a));                                             //eccentricity for planet orbit
    iSetColor(200,200,200);
    double x=px+a*e;                                                             //center of satellite

    if(vis[9]&&distance(x+a*cos(theta*pi/180),py+b*sin(theta*pi/180),starpos[0],starpos[1])<r+str)          //if explosion happens
    {
        sat[2][ind1][ind2]=1;
        vis[9]=0;
        draw_explosion(starpos[0],starpos[1]);
//        iText(100,100,"CLASH!!");
    }

    if(linevis1)iLine(px,py,x+a*cos(theta*pi/180),py+b*sin(theta*pi/180));          //drawing line
    if(satorbit)draworbit(x,py,a,b);                                                   //drawing satellite orbit
    drawplanet(x,py,a,b,r,theta);                                                   //drawing satellite
}


// parameters.. coordinate of sun..axis length a,radius r,theta ans color code RGB...ind planet index number
void draworbitandplanet(double focusx,double focusy,double a,double r,double theta,int color,int ind)
{
    double b;
    b=a*gal_b/gal_a;
    double e=sqrt(1.0-(b*b)/(a*a));
    double x=focusx+a*e;
    int bl=color%256;
    int g=(color/256)%256;
    int rd=(color/(256*256))%256;
    double cx=x+a*cos(theta*pi/180);
    double cy=focusy+b*sin(theta*pi/180);
    if(vis[9]&&distance(cx,cy,starpos[0],starpos[1])<r+str)
    {
        vis[ind]=0;                                                             //explosion check
        vis[9]=0;
        draw_explosion(starpos[0],starpos[1]);
//           iText(100,100,"CLASH!!");
    }
    if(orbitvis)draworbit(x,focusy,a,b);
    iSetColor(255,255,0);
    if(linevis&&color!=0xff0000)iLine(focusx,focusy,x+a*cos(theta*pi/180),focusy+b*sin(theta*pi/180));
    iSetColor(rd,g,bl);
    drawplanet(x,focusy,a,b,r,theta);
}

void iDraw()
{
    iClear();
    iShowBMP(0,0,p[(int)pic]);
    textoutput();
    if(exp_tim)draw_explosion(exppos[0],exppos[1]);
    iSetColor(255,255,0);
    iFilledCircle(sun[0],sun[1],offset*sun[2]);                                     //drawing sun
    if(distance(sun[0],sun[1],starpos[0],starpos[1])<(sun[2]*offset+str))vis[9]=0,draw_explosion(starpos[0],starpos[1]);
    if(vis[9])iShowBMP2(starpos[0],starpos[1],star,0);
    for(int i=0; i<planetnum; i++)
    {
        if(vis[i]==0)continue;
        draworbitandplanet(sun[0],sun[1],offset*planet[i][0],offset*planet[i][1],planet[i][2],planetcolor[i],i);
        for(int j=0; j<sat[0][i][0]; j++)
            if(!sat[2][i][j])drawsat(sun[0],sun[1],offset*planet[i][0],planet[i][2],offset*(planet[i][1]*3+j*10),offset*sat[0][i][j+1],sat[1][i][j],i,j);
    }
}

void iMouseMove(int mx, int my)
{
    sun[0]+=(mx-msx);
    sun[1]+=(my-msy);
    msx=mx,msy=my;
}

void iMouse(int button, int state, int mx, int my)
{
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        msx=mx,msy=my;
    }
    if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
    {
        msx=mx,msy=my;
    }
}

void iKeyboard(unsigned char key)
{
    switch(key)
    {
    case 'q':
    case 'Q':
        exit(0);
    case '+':                               //zoom in
        offset+=offset*0.05;
        break;
    case '-':                              //zoom out
        offset-=offset*0.05;
        break;
    case 'p':                              //pause
    case 'P':
        pause=1;
        iPauseTimer(0);
        break;
    case 'r':                             //resume
    case 'R':
        pause=0;
        iResumeTimer(0);
        break;
    case 'o':                             //orbit visibility
    case 'O':
        orbitvis=1-orbitvis;
        break;
    case 's':                            //satellite orbit visibility
    case 'S':
        satorbit=1-satorbit;
        break;
    case 'C':
        rev*=-1;                        //changing rotation of planet
        break;
    case 'c':
        rev1*=-1;                        //changing rotation of satellite
        break;
    case 'l':
        linevis1=1-linevis1;             //line visibility
        break;
    case 'L':
        linevis=1-linevis;
        break;
    case '*':                              //reset the zoom offset
        offset=0.55;
        break;
    case 'i':
        speedoffset1+=speedoffset1*0.05;    //speed increase for satellite
        break;
    case 'd':
        speedoffset1-=speedoffset1*0.05;    //speed decrease for satellite
        break;
    case 'I':
        speedoffset+=speedoffset*0.05;      //speed increase for planet
        break;
    case 'D':
        speedoffset-=speedoffset*0.05;      //speed decrease for planet
        break;
    case 't':                               //background stuck/animate
    case 'T':
        bg_stuck=1-bg_stuck;
        break;
    default:
        if(key>='0'&&key<='9')              //remove/draw the planet and shooting star
            vis[key-'0']=1-vis[key-'0'];

    }

}

void iSpecialKeyboard(unsigned char key)
{

    if(key == GLUT_KEY_END)
    {
        exit(0);
    }
    if(key == GLUT_KEY_UP)
    {
        sun[1]-=move_offset;                                //moving the scenario
    }
    if(key == GLUT_KEY_DOWN)
    {
        sun[1]+=move_offset;
    }
    if(key == GLUT_KEY_RIGHT)
    {
        sun[0]-=move_offset;
    }
    if(key == GLUT_KEY_LEFT)
    {
        sun[0]+=move_offset;
    }
}
void change()
{
        strappear++;
        if(strappear>170/speedoffset)
        {
            vis[9]=1;
            strappear=0;
            starpos[1]=1050;
            starpos[0]=500+rand()%1000;
        }
        if(vis[9])
        {
            starpos[0]-=10*speedoffset;
            starpos[1]-=10*speedoffset;
        }
        else
        {
            starpos[0]=starpos[1]=-1;
        }
        if(!bg_stuck)pic+=0.01;
        if(pic>=4)pic=0;
        if(exp_tim)
        {
            exp_tim++;
            rd+=0.7,sd+=0.3;
            exp_tim%=60;
        }
        else
        {
            rd=40,sd=15;
        }
        for(int i=0; i<planetnum; i++)
        {
            double dtheta=rev*(4-i/2.5);
            planet[i][2]+=(dtheta*speedoffset);
            planet[i][2]=planet[i][2]-(int)(planet[i][2]/360)*360;
            for(int j=0; j<sat[0][i][0]; j++)
            {
                if(sat[2][i][j])continue;
                double sth=rev1*(3-j/2.0+i/10.0);
                sat[1][i][j]+=sth*speedoffset1;
                sat[1][i][j]=sat[1][i][j]-(int)(sat[1][i][j]/360)*360;
            }
        }
}

int main()
{
    //place your own initialization codes here.
    pi=acos(-1);
    iSetTimer(20,change);
    iInitialize(1500,1024,"SOLAR SYSTEM");
    return 0;
}

